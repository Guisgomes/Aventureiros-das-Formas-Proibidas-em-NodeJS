
var x = 1.5;
var xpto = 0 + (20 * 90 * 75 - 4 + x * ( 20 / 90 /75 + 4 + x * x) ** (20 / 90 / 75 + 4 + x * x) * (2 + 8 * (20 - 1) * - 1)* -1) + 1;



console.log("Alex Silva");
console.info("Alex Silva");
console.error("Alex Silva");
console.warn(xpto);